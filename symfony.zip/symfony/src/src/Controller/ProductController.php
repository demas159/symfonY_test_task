<?php

namespace App\Controller;

use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpKernel\Attribute\AsController;

/* @AsController
 */
class ProductController extends AbstractController
{
    private $doctrine;

    public function __construct(ManagerRegistry $doctrine)
    {
        $this->doctrine = $doctrine;
    }
    public function __invoke(string $isoCode, int $id)
    {
       return $this->getByIsoCodeAndId($isoCode, $id);
    }

    public function getByIsoCodeAndId(string $isoCode, int $id): Response {
        $product = $this->doctrine->getManager()
            ->getRepository("App\Entity\Product")
            ->findOneBy(["id" => $id])
        ;

        if (!$product)
            throw $this->createNotFoundException('The product does not exist');

        $country = $this->doctrine->getManager()
            ->getRepository("App\Entity\Country")
            ->findByIsoCode($isoCode)
        ;

        if (!$country)
            throw $this->createNotFoundException('The country does not exist');

        $vat = $this->doctrine->getManager()
            ->getRepository("App\Entity\Vat")
            ->findRateByCountryAndVatCat($country->getId(), $product->getVatCat()->getId())
        ;

        $vatRate = (!$vat) ? 1 : $vat->getRate();

        return $this->json([
            "Country" => $country->getName(),
            "Product Name" => $product->getName(),
            "Product Description" => $product->getDescription(),
            "Product Original Price" => $product->getPrice(),
            "Tax rate" => $vatRate,
            "Product Price for current country" => $product->getPricePlusVat($vatRate),
            ])
        ;
    }


}

