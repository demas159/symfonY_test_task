<?php

namespace App\Repository;

use App\Entity\VatCat;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @method VatCat|null find($id, $lockMode = null, $lockVersion = null)
 * @method VatCat|null findOneBy(array $criteria, array $orderBy = null)
 * @method VatCat[]    findAll()
 * @method VatCat[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class VatCatRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, VatCat::class);
    }
}
