<?php

namespace App\Entity;

use ApiPlatform\Core\Annotation\ApiResource;
use App\Repository\CountryRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

/**
 * @ApiResource(
 *     collectionOperations={"get", "post"},
 *     itemOperations={"get"={"path"="/country/{id}"}, "put", "delete"},
 *     normalizationContext={"groups"={"country:read"}},
 *     denormalizationContext={"groups"={"country:write"}}
 * )
 * @ORM\Entity(repositoryClass=CountryRepository::class)
 */
class Country
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     * @Groups({"country:read", "country:write"})
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=100)
     * @Groups({"country:read", "country:write"})
     */
    private $name;

    /**
     * @ORM\OneToOne(targetEntity=Locale::class, cascade={"persist", "remove"})
     * @ORM\JoinColumn(nullable=false)
     * @Groups({"country:read", "country:write", "locale:read"})
     */
    private $locale;

    /**
     * @ORM\OneToMany(targetEntity=Vat::class, mappedBy="country", orphanRemoval=true)
     * @Groups({"country:read"})
     */
    private $vat;

    public function __construct()
    {
        $this->vat = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): self
    {
        $this->name = $name;

        return $this;
    }

    public function getLocale(): ?Locale
    {
        return $this->locale;
    }

    public function setLocale(Locale $locale): self
    {
        $this->locale = $locale;

        return $this;
    }

    /**
     * @return Collection|Vat[]
     */
    public function getVat(): Collection
    {
        return $this->vat;
    }

    public function addVat(Vat $vat): self
    {
        if (!$this->vat->contains($vat)) {
            $this->vat[] = $vat;
            $vat->setCountry($this);
        }

        return $this;
    }

    public function removeVat(Vat $vat): self
    {
        if ($this->vat->removeElement($vat)) {
            // set the owning side to null (unless already changed)
            if ($vat->getCountry() === $this) {
                $vat->setCountry(null);
            }
        }

        return $this;
    }
}
