<?php

namespace App\Entity;

use ApiPlatform\Core\Annotation\ApiResource;
use App\Repository\ProductRepository;
use Doctrine\ORM\Mapping as ORM;
use App\Controller\ProductController;

/**
 * @ApiResource(
 *   normalizationContext={"groups" = {"read"}},
 *   denormalizationContext={"groups" = {"write"}},
 *   itemOperations={
 *     "get",
 *     "patch",
 *     "delete",
 *     "put",
 *     "get_by_iso_code_and_id" = {
 *       "method" = "GET",
 *       "path" = "/{isoCode}/product/{id}",
 *       "controller" = ProductController::class,
 *       "read"=true,
 *     "openapi_context" = {
 *         "parameters" = {
 *           {
 *             "name" = "isoCode",
 *             "in" = "path",
 *             "description" = "The iso code of locale and country",
 *             "type" = "string",
 *             "required" = true,
 *             "example"= "en",
 *           },
 *           {
 *             "name" = "id",
 *             "in" = "path",
 *             "description" = "Id of product",
 *             "type" = "int",
 *             "required" = true,
 *             "example"= "1",
 *           },
 *         },
 *       },
 *     },
 *   }
 * )
 * @ORM\Entity(repositoryClass=ProductRepository::class)
 */
class Product
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=50)
     */
    private $name;

    /**
     * @ORM\Column(type="float")
     */
    private $price;

    /**
     * @ORM\Column(type="text", nullable=true)
     */
    private $description;

    /**
     * @ORM\ManyToOne(targetEntity=VatCat::class)
     * @ORM\JoinColumn(nullable=false)
     */
    private $vat_cat;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): self
    {
        $this->name = $name;

        return $this;
    }

    public function getPrice(): ?float
    {
        return $this->price;
    }

    public function setPrice(float $price): self
    {
        $this->price = $price;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): self
    {
        $this->description = $description;

        return $this;
    }

    public function getVatCat(): ?VatCat
    {
        return $this->vat_cat;
    }

    public function setVatCat(?VatCat $vat_cat): self
    {
        $this->vat_cat = $vat_cat;

        return $this;
    }

    public function getPricePlusVat(int $rate): float
    {
        return round($this->getPrice() + ($this->getPrice() * $rate)/100, 2);
    }
}
